#include <stdio.h>
__attribute__((constructor)) void foo() {
  printf("ctor call\n");
}
__attribute__((destructor)) void bar() {
  printf("dtor call\n");
}

int main(int argc, char *argv[], char *envp[]) {
  for (int i = 0; i < argc; i++) {
    printf("argv[%d] = %s\n", i, argv[i]);
  }
  for (char **p = envp; *p; p++) {
    printf("envp[%d]: %s\n", (int)(p - envp), *p);
  }
}
