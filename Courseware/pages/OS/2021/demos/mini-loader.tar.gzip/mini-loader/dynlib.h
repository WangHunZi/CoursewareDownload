#define REC_SZ 32

#ifdef __ASSEMBLER__
  #define DYNLIB_TAB     tab_start:
  #define DYNLIB_TAB_END .align REC_SZ, 0; \
                         .fill REC_SZ, 1, 0

  #define EXPORT(name)   .align REC_SZ, 0; \
                         .quad (name - tab_start); \
                         .asciz #name

  #define IMPORT(name)   .align REC_SZ, 0; \
                         name##_dyn: \
                         .quad 0; \
                         .ascii #name; .asciz "@dynamic"

#else
  #include <stdint.h>
  struct symbol {
    int64_t offset;
    char name[REC_SZ - sizeof(int64_t)];
  };
  #define LENGTH(arr) (sizeof(arr) / sizeof((arr)[0]))
#endif
