#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <elf.h>
#include <readline/readline.h>

#include "dynlib.h"

struct symbol syms[128];

void *dlsym(const char *name) {
  for (int i = 0; i < LENGTH(syms); i++) {
    if (strcmp(syms[i].name, name) == 0) {
      return (void *)syms[i].offset;
    }
  }
  assert(0);
}

void dladd(char *lib, struct symbol *s) {
  for (int i = 0; i < LENGTH(syms); i++)
    if (!syms[i].name[0]) {
      syms[i].offset = (uintptr_t)(lib + s->offset);
      strcpy(syms[i].name, s->name);
      return;
    }
}

int load(const char *fname) {
  printf("Loading %s\n", fname);

  int fd = open(fname, O_RDONLY);
  if (fd < 0) return -1;
  char *lib = mmap(NULL, 4096, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE, fd, 0);
  assert(lib != (void *)-1);

  for (struct symbol *s = (struct symbol *)lib; s->name[0]; s++) {
    char *pos = strchr(s->name, '@');
    int (*fp)();

    if (pos) { // import
      *pos = '\0';
      fp = dlsym(s->name);
      s->offset = (uintptr_t)fp;
      printf("  call %s() get %d\n", s->name, fp());
    } else { // export
      fp = (void *)(lib + s->offset);
      dladd(lib, s);
      printf("  call %s() get %d\n", s->name, fp());
    }
  }
  return 0;
}

int main() {
  load("liba.dynlib");
  load("libb.dynlib");
}
