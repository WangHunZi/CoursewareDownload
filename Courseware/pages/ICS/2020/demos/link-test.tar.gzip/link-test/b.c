int x = 100, y = 200;
